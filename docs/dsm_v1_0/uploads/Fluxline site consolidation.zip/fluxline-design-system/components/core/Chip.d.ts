/**
 * Pill-shaped labels: filter chips (invert to accent when active), uppercase category
 * badges (teal, gold for featured), quiet tag pills, and bordered platform link pills.
 */
export interface ChipProps {
  /** 'filter' | 'badge' | 'tag' | 'platform'. Default 'category' badge behavior via 'badge'. */
  kind?: 'filter' | 'badge' | 'tag' | 'platform';
  /** Badge tint. teal = standard category, gold = featured/TRI. */
  tone?: 'teal' | 'gold';
  /** Filter chips only: selected state (accent fill, dark text). */
  active?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
