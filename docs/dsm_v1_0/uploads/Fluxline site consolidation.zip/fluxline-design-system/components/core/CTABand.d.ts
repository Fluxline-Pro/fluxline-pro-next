/**
 * Full-width closing CTA — navy gradient band with faint 44px grid overlay, centered
 * white headline, mist body, primary + optional outline button. One per page, near the end.
 * @startingPoint section="Core" subtitle="Gradient CTA band with grid overlay" viewport="900x320"
 */
export interface CTABandProps {
  title: React.ReactNode;
  body?: React.ReactNode;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
  /** Show the faint grid overlay. Default true. */
  grid?: boolean;
  style?: React.CSSProperties;
}
