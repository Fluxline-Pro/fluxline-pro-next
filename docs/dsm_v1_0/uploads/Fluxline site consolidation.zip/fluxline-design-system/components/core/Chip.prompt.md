Pill labels — filter rows, category badges, tags, and platform links (Spotify/Apple/RSS).

```jsx
<Chip kind="filter" active onClick={...}>All</Chip>
<Chip kind="badge">Resonant Identity</Chip>
<Chip kind="badge" tone="gold">Featured</Chip>
<Chip kind="tag">somatic awareness</Chip>
<Chip kind="platform" onClick={...}>Spotify</Chip>
```

Gold tone is reserved for featured/special moments (TRI, milestones). Filter chips invert to the accent fill when active.
