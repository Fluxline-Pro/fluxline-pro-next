import React from 'react';

export function StatCard({ value, label, style }) {
  return React.createElement('div', {
    style: {
      background: 'var(--fx-surface-card)', border: '1px solid var(--fx-border)',
      borderRadius: 'var(--fx-radius-card-sm)', padding: '20px 18px', textAlign: 'center',
      fontFamily: 'var(--fx-font)', ...style,
    },
  },
    React.createElement('div', { style: { fontSize: 30, fontWeight: 800, color: 'var(--fx-text-heading)' } }, value),
    React.createElement('div', { style: { fontSize: 13, color: 'var(--fx-text-muted)', marginTop: 4 } }, label),
  );
}
