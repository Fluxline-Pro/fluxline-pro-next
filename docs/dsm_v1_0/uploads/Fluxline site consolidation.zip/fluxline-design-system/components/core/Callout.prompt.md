Tinted attention box for statements and confirmations — use sparingly, one per view.

```jsx
<Callout title="We're Not Done Yet—But We're Already Extraordinary.">
  <em>Modular by design. Resonant by nature.</em>
</Callout>
<Callout tone="success" title="✓ Note sent">Thanks — we've got it.</Callout>
```
