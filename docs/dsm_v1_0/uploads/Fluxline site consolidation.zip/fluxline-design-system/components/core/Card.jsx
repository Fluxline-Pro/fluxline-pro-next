import React from 'react';

export function Card({ variant = 'standard', interactive = false, href, padding, children, style }) {
  const [hover, setHover] = React.useState(false);
  const backgrounds = {
    standard: 'var(--fx-surface-card)',
    inset: 'var(--fx-surface-inset)',
    raised: 'var(--fx-surface-raised)',
    feature: 'var(--fx-gradient-feature)',
    band: 'var(--fx-gradient-band)',
  };
  const border = (variant === 'feature' || variant === 'band')
    ? '1px solid var(--fx-border-strong)'
    : '1px solid ' + (interactive && hover ? 'var(--fx-border-hover)' : 'var(--fx-border)');
  const s = {
    display: 'block', background: backgrounds[variant], border,
    borderRadius: variant === 'band' ? 'var(--fx-radius-band)' : 'var(--fx-radius-card)',
    padding: padding != null ? padding : 'var(--fx-card-pad)',
    fontFamily: 'var(--fx-font)', color: 'var(--fx-text-body)', textDecoration: 'none',
    transition: 'border-color var(--fx-hover-duration), transform var(--fx-hover-duration)',
    transform: interactive && hover ? 'var(--fx-hover-lift)' : 'none',
    ...style,
  };
  const props = { style: s, onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false) };
  return href
    ? React.createElement('a', { href, ...props }, children)
    : React.createElement('div', props, children);
}
