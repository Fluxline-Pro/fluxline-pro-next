Section opener — heading + teal statement line. Open every major section with one.

```jsx
<SectionHeading
  title="About Fluxline"
  subhead="Systems that work, brands that connect, and practices that last."
  lede="Fluxline is built on the belief that congruence creates momentum." />
```
