Form field with the Fluxline treatment — dark fill, quiet border, soft label.

```jsx
<Input label="Name *" placeholder="Your name" value={v} onChange={fn} />
<Input label="Message *" textarea placeholder="What are you building?" />
```

Inline subscribe rows omit the label and pair the input with a primary Button.
