import React from 'react';

export function Input({ label, textarea = false, value, onChange, placeholder, rows = 6, style }) {
  const field = {
    width: '100%', background: 'var(--fx-surface-input)', border: '1px solid var(--fx-border)',
    borderRadius: 'var(--fx-radius-control)', padding: '12px 14px', fontSize: 14.5,
    color: 'var(--fx-text-bright)', outline: 'none', fontFamily: 'var(--fx-font)',
    boxSizing: 'border-box', resize: textarea ? 'vertical' : undefined, ...style,
  };
  return React.createElement('div', null,
    label && React.createElement('label', {
      style: { display: 'block', fontSize: 12.5, fontWeight: 600, color: 'var(--fx-text-soft)', marginBottom: 6, fontFamily: 'var(--fx-font)' },
    }, label),
    React.createElement(textarea ? 'textarea' : 'input', { value, onChange, placeholder, rows: textarea ? rows : undefined, style: field }),
  );
}
