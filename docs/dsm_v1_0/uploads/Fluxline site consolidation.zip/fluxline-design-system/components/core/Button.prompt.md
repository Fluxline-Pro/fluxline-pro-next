Fluxline button — use for every action; primary is the light-periwinkle fill, and there is never more than one primary per view section.

```jsx
<Button href="#contact">Book a Consultation</Button>
<Button variant="outline">Explore Fluxline ↓</Button>
<Button variant="quiet">← Back to all services</Button>
```

Variants: `primary` (fill `--fx-accent`, dark text, hover brightness 1.08), `outline` (1px `--fx-line` border, hover soft fill), `quiet` (bare link, hover brightens). Sizes: `sm` (nav), `md`, `lg` (CTA bands). Use unicode `→ ← ↓ ›` for direction — never icon fonts.
