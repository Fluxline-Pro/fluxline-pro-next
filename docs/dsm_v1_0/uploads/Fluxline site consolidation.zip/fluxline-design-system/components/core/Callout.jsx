import React from 'react';

export function Callout({ tone = 'gold', title, children, style }) {
  const tones = {
    gold: { border: 'var(--fx-gold-border)', bg: 'var(--fx-gold-bg)', titleColor: 'var(--fx-gold)' },
    success: { border: 'var(--fx-success-border)', bg: 'var(--fx-success-bg)', titleColor: 'var(--fx-success)' },
  };
  const t = tones[tone] || tones.gold;
  return React.createElement('div', {
    style: {
      border: '1px solid ' + t.border, background: t.bg,
      borderRadius: 'var(--fx-radius-card-sm)', padding: '22px 26px',
      fontFamily: 'var(--fx-font)', ...style,
    },
  },
    title && React.createElement('div', { style: { fontWeight: 700, fontSize: 17, color: t.titleColor, marginBottom: 4 } }, title),
    React.createElement('div', { style: { fontSize: 14.5, lineHeight: 1.6, color: 'var(--fx-text-body)' } }, children),
  );
}
