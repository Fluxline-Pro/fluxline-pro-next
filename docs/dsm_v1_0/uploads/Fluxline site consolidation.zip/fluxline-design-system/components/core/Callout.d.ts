/**
 * Tinted attention box. Gold = brand statements / featured notes ("We're Not Done Yet…");
 * success (teal) = confirmations ("✓ Note sent").
 */
export interface CalloutProps {
  /** Default 'gold'. */
  tone?: 'gold' | 'success';
  /** Bold colored first line. */
  title?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
