Impact statistic tile — always in a grid of 3–4, never alone.

```jsx
<div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14}}>
  <StatCard value="50+" label="Projects Delivered" />
  <StatCard value="20+" label="Years Experience" />
</div>
```
