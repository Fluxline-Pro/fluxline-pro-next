import React from 'react';

const base = {
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  borderRadius: 'var(--fx-radius-control)', fontFamily: 'var(--fx-font)',
  fontWeight: 600, textDecoration: 'none', cursor: 'pointer',
  transition: 'filter var(--fx-color-duration), background var(--fx-color-duration), color var(--fx-color-duration), border-color var(--fx-color-duration)',
};

const sizes = {
  sm: { fontSize: 14, padding: '9px 18px' },
  md: { fontSize: 15, padding: '13px 26px' },
  lg: { fontSize: 15.5, padding: '14px 30px' },
};

const variants = {
  primary: { background: 'var(--fx-accent)', color: 'var(--fx-accent-ink)', border: 'none' },
  outline: { background: 'transparent', color: 'var(--fx-accent)', border: '1px solid var(--fx-line)' },
  quiet: { background: 'transparent', color: 'var(--fx-text-soft)', border: 'none', padding: 0 },
};

export function Button({ variant = 'primary', size = 'md', href, onClick, children, style }) {
  const [hover, setHover] = React.useState(false);
  const hoverStyle = hover
    ? variant === 'primary' ? { filter: 'brightness(1.08)' }
    : variant === 'outline' ? { background: 'rgba(184,205,245,0.08)' }
    : { color: 'var(--fx-text-bright)' }
    : {};
  const s = { ...base, ...sizes[size], ...variants[variant], ...hoverStyle, ...style };
  const props = { style: s, onClick, onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false) };
  return href
    ? React.createElement('a', { href, ...props }, children)
    : React.createElement('button', { type: 'button', ...props }, children);
}
