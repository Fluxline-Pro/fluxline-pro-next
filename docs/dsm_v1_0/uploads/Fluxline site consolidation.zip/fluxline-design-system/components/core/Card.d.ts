/**
 * Fluxline surface container. Flat dark fill + 1px border, NO shadows — elevation is
 * border brightening + a −3px lift when interactive. Feature/band variants use the navy
 * gradients with the strong border.
 * @startingPoint section="Core" subtitle="Flat bordered surfaces, no shadows" viewport="700x220"
 */
export interface CardProps {
  /** standard #11161F · inset #0D1117 · raised #141A25 · feature/band gradients. */
  variant?: 'standard' | 'inset' | 'raised' | 'feature' | 'band';
  /** Adds hover border-brighten + lift. Automatic affordance for link cards. */
  interactive?: boolean;
  /** Renders as <a>. Pair with interactive. */
  href?: string;
  /** CSS padding override. Default var(--fx-card-pad) (24px). */
  padding?: string | number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
