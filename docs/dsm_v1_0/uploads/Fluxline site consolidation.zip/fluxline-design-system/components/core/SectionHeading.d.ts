/**
 * The Fluxline section opener: optional uppercase teal kicker, periwinkle heading,
 * optional teal statement subhead, optional body lede. Every section starts with one.
 */
export interface SectionHeadingProps {
  /** Uppercase teal label above the title, e.g. "Body & Practice". */
  kicker?: string;
  title: React.ReactNode;
  /** Teal 19px/600 statement line, e.g. "Modular by design. Resonant by nature." */
  subhead?: React.ReactNode;
  /** Body paragraph under the subhead. */
  lede?: React.ReactNode;
  /** Heading level/scale. Default 'h2'. */
  as?: 'h1' | 'h2' | 'h3';
  style?: React.CSSProperties;
}
