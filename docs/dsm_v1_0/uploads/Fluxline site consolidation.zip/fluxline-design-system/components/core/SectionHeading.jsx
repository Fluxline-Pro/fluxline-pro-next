import React from 'react';

export function SectionHeading({ kicker, title, subhead, lede, as = 'h2', style }) {
  const sizes = { h1: 38, h2: 34, h3: 23 };
  return React.createElement('div', { style: { fontFamily: 'var(--fx-font)', maxWidth: 680, ...style } },
    kicker && React.createElement('div', {
      style: { fontSize: 'var(--fx-kicker-size)', fontWeight: 600, letterSpacing: 'var(--fx-kicker-tracking)', textTransform: 'uppercase', color: 'var(--fx-teal)', marginBottom: 12 },
    }, kicker),
    React.createElement(as, {
      style: { fontSize: sizes[as] || 34, fontWeight: as === 'h1' ? 800 : 700, color: 'var(--fx-text-heading)', margin: '0 0 10px', letterSpacing: 'var(--fx-heading-tracking)', lineHeight: 1.2 },
    }, title),
    subhead && React.createElement('p', {
      style: { fontSize: 'var(--fx-subhead-size)', fontWeight: 'var(--fx-subhead-weight)', color: 'var(--fx-teal)', margin: '0 0 14px', lineHeight: 1.45 },
    }, subhead),
    lede && React.createElement('p', {
      style: { fontSize: 'var(--fx-body-size)', lineHeight: 'var(--fx-body-leading)', color: 'var(--fx-text-body)', margin: 0 },
    }, lede),
  );
}
