import React from 'react';

export function Chip({ kind = 'category', tone = 'teal', active = false, onClick, children, style }) {
  const [hover, setHover] = React.useState(false);
  const pill = { display: 'inline-flex', alignItems: 'center', gap: 6, borderRadius: 'var(--fx-radius-pill)', fontFamily: 'var(--fx-font)', fontWeight: 600, transition: 'all var(--fx-color-duration)', ...style };
  let s;
  if (kind === 'filter') {
    s = { ...pill, cursor: 'pointer', padding: '8px 16px', fontSize: 13,
      border: '1px solid ' + (active ? 'var(--fx-accent)' : 'var(--fx-border)'),
      background: active ? 'var(--fx-accent)' : 'transparent',
      color: active ? 'var(--fx-accent-ink)' : (hover ? 'var(--fx-text-bright)' : 'var(--fx-text-muted)') };
  } else if (kind === 'badge') {
    s = { ...pill, padding: '5px 12px', fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
      background: tone === 'gold' ? 'rgba(232,185,91,0.14)' : 'var(--fx-teal-bg)',
      color: tone === 'gold' ? 'var(--fx-gold)' : 'var(--fx-teal)' };
  } else if (kind === 'tag') {
    s = { ...pill, padding: '5px 13px', fontSize: 12, color: 'var(--fx-text-soft)', border: '1px solid var(--fx-border)' };
  } else { // platform pill link
    s = { ...pill, cursor: 'pointer', padding: '6px 13px', fontSize: 12,
      border: '1px solid ' + (hover ? 'var(--fx-border-hover)' : 'var(--fx-border-strong)'),
      color: hover ? 'var(--fx-text-bright)' : 'var(--fx-accent)', textDecoration: 'none' };
  }
  return React.createElement(onClick ? 'button' : 'span',
    { style: onClick ? { ...s, border: s.border || 'none' } : s, onClick,
      onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false), type: onClick ? 'button' : undefined },
    children);
}
