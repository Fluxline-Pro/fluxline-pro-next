/**
 * Fluxline action button. Primary = light-periwinkle fill with dark text (the ONLY filled
 * button color). Outline = steel border with periwinkle text. Quiet = bare soft-blue link.
 * @startingPoint section="Core" subtitle="Primary, outline and quiet actions" viewport="700x180"
 */
export interface ButtonProps {
  /** Visual style. Default 'primary'. */
  variant?: 'primary' | 'outline' | 'quiet';
  /** Default 'md'. sm = nav CTA, lg = band CTA. */
  size?: 'sm' | 'md' | 'lg';
  /** Renders an <a> when set, otherwise a <button>. */
  href?: string;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
