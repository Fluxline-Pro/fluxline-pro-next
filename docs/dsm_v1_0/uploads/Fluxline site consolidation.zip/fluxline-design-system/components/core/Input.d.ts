/**
 * Form field — deep-dark fill, standard border, soft-blue label above. Required fields
 * are marked with " *" in the label text.
 */
export interface InputProps {
  /** Label above the field, e.g. "E-mail *". */
  label?: string;
  /** Render a <textarea> instead of <input>. */
  textarea?: boolean;
  value?: string;
  onChange?: (e: any) => void;
  placeholder?: string;
  /** Textarea rows. Default 6. */
  rows?: number;
  style?: React.CSSProperties;
}
