Closing CTA band — the "Ready to structure the shift?" pattern. One per page.

```jsx
<CTABand
  title="Ready to structure the shift?"
  body="Tell us where you are and where you're going. We'll map the right first step together."
  primaryLabel="Book a Consultation" primaryHref="/contact"
  secondaryLabel="Full Contact Form →" secondaryHref="/contact" />
```
