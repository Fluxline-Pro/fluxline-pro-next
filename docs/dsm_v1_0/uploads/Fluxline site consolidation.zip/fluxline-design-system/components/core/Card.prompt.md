Surface container for everything card-shaped — service links, posts, panels, CTA bands.

```jsx
<Card interactive href="/services/design">
  <Chip kind="badge">Read</Chip>
  <h3 style={{color:'var(--fx-text-heading)'}}>Brand & Experience Design</h3>
</Card>
<Card variant="band" padding="58px 48px">…centered CTA…</Card>
```

Variants: `standard`, `inset` (nested panels), `raised` (grid link-cards), `feature` (gradient, strong border — featured content like TRI), `band` (gradient, 20px radius — full-width CTA sections). Never add box-shadow.
