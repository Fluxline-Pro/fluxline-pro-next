/**
 * Centered impact statistic — big periwinkle number over a muted label ("50+ Projects
 * Delivered"). Used in 4-up grids in the About section.
 */
export interface StatCardProps {
  /** The figure, e.g. "50+". */
  value: string;
  /** e.g. "Projects Delivered". */
  label: string;
  style?: React.CSSProperties;
}
