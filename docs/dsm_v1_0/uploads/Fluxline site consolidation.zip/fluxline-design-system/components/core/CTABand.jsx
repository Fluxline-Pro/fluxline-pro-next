import React from 'react';
import { Button } from './Button.jsx';

export function CTABand({ title, body, primaryLabel, primaryHref, secondaryLabel, secondaryHref, grid = true, style }) {
  return React.createElement('div', {
    style: {
      position: 'relative', overflow: 'hidden', background: 'var(--fx-gradient-band)',
      border: '1px solid var(--fx-border-strong)', borderRadius: 'var(--fx-radius-band)',
      padding: '58px 48px', textAlign: 'center', fontFamily: 'var(--fx-font)', ...style,
    },
  },
    grid && React.createElement('div', {
      style: { position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(174,198,238,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(174,198,238,.05) 1px,transparent 1px)', backgroundSize: '44px 44px' },
    }),
    React.createElement('div', { style: { position: 'relative' } },
      React.createElement('h2', { style: { fontSize: 36, fontWeight: 800, color: '#FFFFFF', margin: '0 0 12px', letterSpacing: '-.01em' } }, title),
      body && React.createElement('p', { style: { fontSize: 16.5, lineHeight: 1.6, color: 'var(--fx-text-mist)', margin: '0 auto 28px', maxWidth: '56ch' } }, body),
      React.createElement('div', { style: { display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' } },
        primaryLabel && React.createElement(Button, { size: 'lg', href: primaryHref }, primaryLabel),
        secondaryLabel && React.createElement(Button, { size: 'lg', variant: 'outline', href: secondaryHref }, secondaryLabel),
      ),
    ),
  );
}
