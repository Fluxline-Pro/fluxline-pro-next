# Fluxline Design System

Design system for **Fluxline Resonance Group, LLC** (fluxline.pro) — a systems-design and consulting practice founded by Terence Waters, spanning web development, brand design, personal training/coaching, and strategic consulting. Tagline: **"Structure the Shift."** Core belief: *congruence creates momentum*.

Extracted from the consolidated single-page prototype built in this project (July 2026):
- `Fluxline One-Page v1.dc.html` — home scroller (Hero → About & Ethos → Services → Content → Contact)
- `Fluxline Service — Design v1.dc.html` — service detail page pattern
- `Fluxline Content Hub v1.dc.html`, `Fluxline Blog v1.dc.html`, `Fluxline Blog Post v1.dc.html`
- `Fluxline Contact v1.dc.html`, `Fluxline 404 v1.dc.html`

Source of truth for brand facts: https://fluxline.pro (About, Services, Ethos, Content, Blog, TRI Podcast pages).

## Products represented

1. **Fluxline.pro website** — dark, editorial marketing site (the UI kit here).
2. **The Resonant Identity (TRI)** — podcast + newsletter sub-brand; uses the gold accent.

## CONTENT FUNDAMENTALS

- **Voice:** first-person plural ("We build congruence"), addressing "you." Confident, warm, declarative. Short sentence fragments used for rhythm: "Strong bodies. Clear brands. Resilient systems."
- **Signature lines** (reuse verbatim, don't paraphrase): "Structure the Shift" · "Modular by design. Resonant by nature." · "Congruence creates momentum." · "We're Not Done Yet—But We're Already Extraordinary."
- **Vocabulary:** resonance, congruence, alignment, identity, embodiment, stewardship, modular, intentional. Blends technical precision language with somatic/emotional language — that pairing IS the brand.
- **Casing:** Title Case for headings and nav ("Choose What Kind Of Support You Need"); sentence case for body. CTA links are ALL-CAPS tracked ("LEARN MORE ›").
- **CTAs:** verbs + invitation, never pushy: "Book a Consultation", "Start a Conversation", "Explore Fluxline".
- **Emoji:** never. Trademark ™ used on "Resonance Core Framework™".
- **Reassurances:** small trust lines near forms ("No spam, ever.").

## VISUAL FOUNDATIONS

- **Mode:** dark only. Near-black blue pages (`--fx-bg-page #0A0D13`), deeper chrome (`#07090D`).
- **Color roles:** periwinkle blue `#AEC6EE` for headings; light periwinkle `#B8CDF5` as the ONLY filled-button color (dark text on it); teal `#4FD1C5` for kickers/subheads/inline CTAs/success; gold `#E8B95B` reserved for featured/special moments (TRI, milestone callouts); steel `#5E81A8` for outlines, constellation lines, hover borders. No other hues. No purple gradients.
- **Backgrounds:** flat dark surfaces; heroes/CTA bands use subtle navy gradients (`--fx-gradient-hero`, `--fx-gradient-band`) plus either a faint constellation SVG (thin `#5E81A8` lines + pulsing dots) or a faint 44px grid overlay at ~5% white.
- **Type:** **Inter** (variable font, preloaded on the live site) — stack: `inter-variable, -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif` (`--fx-font`; this project loads Inter from Google Fonts via `tokens/typography.css`). Display is heavy (800) and *tracked out* (+0.06em); h1/h2 tight (−0.01em). Teal 19px/600 statement line sits under most headings. Body 16px/1.7.
- **Cards:** `--fx-surface-card` fill, 1px `--fx-border`, radius 12–16px, **no shadows anywhere** — elevation is border + lift.
- **Hover:** border brightens to `#5E81A8` + `translateY(-3px)`, 0.18s. Buttons: `brightness(1.08)`. Links: color to `#EAF0F9`, 0.15s. No press/shrink states.
- **Motion:** one easing `cubic-bezier(.2,0,0,1)`. Scroll-reveal rise (26px, 1.2s) via IntersectionObserver; pulsing constellation dots. Nothing bouncy. `prefers-reduced-motion` respected.
- **Layout:** 1220px container, 32px gutters, 88px section rhythm. Signature pattern: **sticky 320px left image rail + scrolling right content**. Long-form reads at 760px. Fixed nav (76px clearance) with `rgba(7,9,13,.82)` + 12px backdrop blur — the only transparency/blur use.
- **Navigation UX:** every subpage carries a "← Back" bordered pill + breadcrumb in the nav, plus back links in rail and footer. Anchor links (no active tracking) on the one-pager.
- **Imagery:** photographic, cool/dark-toned, shown inside rail cards with a caption strip; TRI uses its illustrated logo. Never full-bleed behind text.
- **Chips/pills:** radius 999px; filter chips invert to accent fill when active; category badges are tinted-bg + colored text (teal or gold at ~12% alpha).

## ICONOGRAPHY

- **No icon font and no icon set.** The prototype uses zero icons by design — hierarchy is carried by type, color, and chips. Unicode glyphs serve as directional marks: `←` `→` `›` `↓` `✓` `·`. Keep it that way; if a project truly needs icons, use Lucide (1.8px stroke) sparingly and flag it.
- **Logos (in `assets/`):** `FluxlineLogo.png` (FX monogram + wordmark, periwinkle/gold on black — default on dark), `FluxlineLogoLightMode.png` (navy/gold on white — print/light contexts only), `FluxlineLogoHomePage.png` (grey check glyph watermark). Sub-brand: `TheResonantIdentity_Logo.png` (full lockup) and `TheResonantIdentity_Icon.png` (teal compass mark) — TRI is teal/black, always paired with the gold-accent treatment in UI. **Never redraw or recolor the marks.**
- **Imagery (in `assets/`):** `HomePageMobileGeometricBackground.jpg` — the teal geometric network that inspired the hero constellation; use it as the hero/section backdrop (cover, ~50% opacity under a dark gradient) instead of hand-drawn SVG lines. `HomePageCover4kLandscape.jpg` — founder portrait (team cards, About). `The-Resonance-Core-Book.jpg` — RCF book cover (content/product cards).

## Index

- `styles.css` — global entry; imports everything in `tokens/`.
- `tokens/colors.css` · `typography.css` · `spacing.css` · `effects.css` — all `--fx-*` custom properties + reveal keyframes.
- `components/core/` — Button, Chip, Card, StatCard, Callout, Input, SectionHeading, CTABand (+ `.d.ts` contracts, `.prompt.md` usage notes).
- `ui_kits/fluxline-web/index.html` — representative home-page screen.
- `guidelines/*.html` — foundation specimen cards (rendered in the Design System tab).
- `SKILL.md` — portable Agent Skill wrapper.
- Full-page prototypes (`Fluxline One-Page v1.dc.html` etc.) live in the source project "Fluxline site consolidation", not in this package — `ui_kits/fluxline-web/index.html` is the reference screen here.

## Intentional additions

- `SectionHeading` and `CTABand` are compositions (not atomic primitives) promoted to components because the pattern repeats on every page of the prototype.
